Manfred Gawlas 279722

By skompilować, należy wejść do directory i następnie wpisać:
```bash
make
```

Następnie nazwa pliku to będzie `279722` czyli mój numer indeksu. Program można uruchomić:
```bash
./27922 <IP> <Port> <Kolejność ruchu(1/2)> <nazwa> <głębokość>
```

---

Zip posiada pliki `main.cpp` i `board.h` które są albo są bazowane na kodzie Pana Profesora Gębali.
